ExpensO - Business sample data (synthetic)
==========================================
A made-up trading business ("Sharma Traders"): items, customers and
suppliers, three months of invoices, payments, and a small payroll. Nothing
here is real. Amounts are in INR.

Business features in ExpensO are coming soon. When they are released:

* inventory-items.csv can be loaded with Inventory > Import. Its columns
  (Name, Unit, Price, Cost, SKU, Group, Opening stock, Low stock level) are
  matched by header name.
* The other files are plain CSVs for reference and for trying your own
  imports or spreadsheets: customers-suppliers, tax-items, invoices,
  invoice-lines, payments, employees, attendance-september-2026.

Salary rule used by the app:
  payable = monthly salary x min(days present, basis) / basis
